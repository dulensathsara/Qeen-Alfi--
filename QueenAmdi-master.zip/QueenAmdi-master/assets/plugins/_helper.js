/*
░██████╗░██╗░░░██╗███████╗███████╗███╗░░██╗
██╔═══██╗██║░░░██║██╔════╝██╔════╝████╗░██║
██║██╗██║██║░░░██║█████╗░░█████╗░░██╔██╗██║
╚██████╔╝██║░░░██║██╔══╝░░██╔══╝░░██║╚████║
░╚═██╔═╝░╚██████╔╝███████╗███████╗██║░╚███║
░░░╚═╝░░░░╚═════╝░╚══════╝╚══════╝╚═╝░░╚══╝
░█████╗░███╗░░░███╗██████╗░██╗
██╔══██╗████╗░████║██╔══██╗██║
███████║██╔████╔██║██║░░██║██║
██╔══██║██║╚██╔╝██║██║░░██║██║ █▀█ █▀▀█ █▀█ ▄█─ 
██║░░██║██║░╚═╝░██║██████╔╝██║ ─▄▀ █▄▀█ ─▄▀ ─█─ 
╚═╝░░╚═╝╚═╝░░░░░╚═╝╚═════╝░╚═╝ █▄▄ █▄▄█ █▄▄ ▄█▄
Copyright (C) 2021 Black Amda.
Licensed under the  GPL-3.0 License;
you may not use this file except in compliance with the License.

Coded by : Sasmitha (Sinhalaya Creator)
*/

const QueenAmdi = require('queenamdi-public');
const Amdi = QueenAmdi.events
const _amdi = QueenAmdi.panel

const Language = require('../language');
const Lang = Language.getString('helper');

Amdi.operate({ pattern: 'helper ?(.*)', fromMe: true, desc: Lang.DESC, deleteCommand: false, dontAddCommandList: true}, (async (amdiMSG, input) => {
    await QueenAmdi.amdi_setup()
    const help_CMD = input[1]
    await _amdi.helper( amdiMSG, help_CMD, Lang )
}));