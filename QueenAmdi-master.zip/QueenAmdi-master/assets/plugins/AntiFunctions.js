/*
░██████╗░██╗░░░██╗███████╗███████╗███╗░░██╗
██╔═══██╗██║░░░██║██╔════╝██╔════╝████╗░██║
██║██╗██║██║░░░██║█████╗░░█████╗░░██╔██╗██║
╚██████╔╝██║░░░██║██╔══╝░░██╔══╝░░██║╚████║
░╚═██╔═╝░╚██████╔╝███████╗███████╗██║░╚███║
░░░╚═╝░░░░╚═════╝░╚══════╝╚══════╝╚═╝░░╚══╝
░█████╗░███╗░░░███╗██████╗░██╗
██╔══██╗████╗░████║██╔══██╗██║
███████║██╔████╔██║██║░░██║██║
██╔══██║██║╚██╔╝██║██║░░██║██║ █▀█ █▀▀█ █▀█ ▄█─ 
██║░░██║██║░╚═╝░██║██████╔╝██║ ─▄▀ █▄▀█ ─▄▀ ─█─ 
╚═╝░░╚═╝╚═╝░░░░░╚═╝╚═════╝░╚═╝ █▄▄ █▄▄█ █▄▄ ▄█▄
Copyright (C) 2021 Black Amda.
Licensed under the  GPL-3.0 License;
you may not use this file except in compliance with the License.
*/

const QueenAmdi = require('queenamdi-public');
const Amdi = QueenAmdi.events
const _amdi = QueenAmdi.antiFunctions
const Build = QueenAmdi.build

Amdi.operate(
    {on: 'text', fromMe: false,  deleteCommand: false}, (async (amdiMSG) => {  
    await QueenAmdi.amdi_setup()  

    await _amdi.fakeBots( amdiMSG )
    
    if (Build.ANTIBAD == 'true') {
        await _amdi.antiBad( amdiMSG )
    }
    
    if (Build.ANTIBUG == 'true') {
        await _amdi.antiBug( amdiMSG )
    }

    if (Build.ANTILINK == 'true') {
        await _amdi.antiLink( amdiMSG )
    }
}));